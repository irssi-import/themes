#!/usr/bin/perl
use strict;
use warnings;
use Irssi;

sub get_nicks_by_mask {
	my ($channel, $mask) = @_;
	my @r;
	for my $nick ($channel->nicks) {
		push @r, $nick if
		($channel->{server}->mask_match_address($mask,$nick->{nick},
		$nick->{host}));
	}
	return @r;
}

sub get_mode_char {
	my ($nick) = @_;
	return '@' if $nick->{op};
	return '%' if $nick->{halfop};
	return '+' if $nick->{voice};
	return '';
}

sub show_affected {
	my ($channel, $ban) = @_;
	return unless $channel->{synced};
	my @nicks = get_nicks_by_mask ($channel, $ban->{ban});
	my $str;
	for (@nicks) {
		$str .= get_mode_char($_) . $_->{nick} . ', ';
	}
	if (defined $str) {
		$str =~ s/, $//;
		$channel->printformat (MSGLEVEL_CRAP, 'ban_affects', $ban->{ban}, $str);
	}
}

Irssi::signal_add ('ban new', \&show_affected);
Irssi::theme_register (['ban_affects', '%R(%W!%R)%n Ban {hilight $0} affects: %R$1' ])
