use strict;
use warnings;
use Irssi;

sub cmd_whoami {
	my ($totalchans, $totalopped, $networks) = (0,0);
	for my $srv (Irssi::servers) {
		my $s = "$srv->{tag}: ";
		if ($srv->{connected}) {
			$networks++;
			my $lag = $srv->{lag} / 1000;
			my ($chans, $opped);
			$lag =~ s/(\.\d\d).*/$1/;
			$chans = $opped = 0;
			for my $chanrec ($srv->channels) {
				$chans++, $totalchans++;
				$totalopped++, $opped++ if $chanrec->{chanop};
			}	
			$s .= "$srv->{nick}!$srv->{userhost} on $srv->{address} (lag: $lag), opped in $opped/$chans channels";
		} else {
			$s .= "(connecting...)";
		}	
		print $s;
	}
	print "total: opped on $totalopped/$totalchans channels on $networks network", $networks > 1 ? "s" : "";
}

Irssi::command_bind ('whoami', \&cmd_whoami);

