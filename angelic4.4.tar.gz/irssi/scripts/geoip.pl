# Print the country name in /WHOIS replies
# /GEOIP <ip/host> prints the country name for the host/ip
# /SET geoip_dat /full/path/to/GeoIP.dat
#
# http://www.maxmind.com/download/geoip/database/GeoLiteCity.dat.gz

use strict;
use Geo::IP;
use Irssi;
use Socket;

use vars qw($VERSION %IRSSI);
$VERSION = "0.0.3";
%IRSSI = (
	authors         => "Toni Viemer�",
	contact         => "toni.viemero\@iki.fi",
	name            => "geoip",
	description     => "Print the users country name in /WHOIS replies",
	license         => "Public Domain",
	changed         => "Wed Nov 19 14:34:12 EET 2003"
);

sub get_record {
	my ($host) = @_;
    my $database = Irssi::settings_get_str("geoip_dat");
	my $gi = Geo::IP->open($database, GEOIP_STANDARD);
    my ($record, $ret);
    if ($host =~ /^[0-9\.]*$/) {
        $record = $gi->record_by_addr($host);
    } else {
        $record = $gi->record_by_name($host);
	}
	$ret = 'Unknown';
	if (defined $record) {
		if (length $record->city) {
			$ret = $record->city . ', ' . $record->region_name . ', '. $record->country_name
		} else {
			$ret = $record->country_name
		}
	}
	return $ret;
}

sub event_whois {
    my $cdata = "";
    my ($server, $data, $nick, $host) = @_;
    my ($me, $nick, $user, $host) = split(" ", $data);
    $cdata = get_record $host;
	$server->printformat($nick, MSGLEVEL_CRAP, 'whois_geoip', $host, $cdata);
}

sub cmd_geoip {
    my $country = "";
    my $host = lc shift;
    if ($host eq "") {
        Irssi::print("Usage: /GEOIP <host/ip>");
        return;
    }
    $country = get_record $host;
	Irssi::print("$host is in $country");
}

sub cmd_geowho {
	my ($ch, $server, $witem) = @_;
	$ch =~ s/ +$//;
	if ($ch eq "") {
		Irssi::print ("Usage: /geowho (ircnet/)#chan");
		return;
	}
	my %data;
	my $chan = $server->channel_find($ch);
	print "please wait...";
	for my $n ($chan->nicks) {
		my $h = $n->{host};
		$h =~ s/^.*@//;
		my $c = get_record $h;
		push @{$data{$c}}, $n->{nick};
	}
	for my $c (sort keys %data) {
		print "%_$c%_: @{[sort @{$data{$c}}]}";
	}
}

Irssi::theme_register([
    'whois_geoip' => '{whois geoip %|$1}'
]);

Irssi::command_bind('geoip', \&cmd_geoip);
Irssi::command_bind('geowho', \&cmd_geowho);
Irssi::signal_add_last('event 311', 'event_whois');
Irssi::settings_add_str("misc", "geoip_dat",
                                Irssi::get_irssi_dir() . "/GeoIP.dat");
