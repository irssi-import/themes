#!perl -wl
use strict;
use Lingua::Translate;
use Irssi;

sub translate {
	return if scalar @_ != 3;
	my ($from, $to, $what) = @_;
	my $trans = new Lingua::Translate src => $from, dest => $to;
	return $trans->translate($what);
}

sub cmd_translate {
	my ($data, $server, $witem) = @_;
	my @args = split /\s+/, $data, 3;
	my $tr = translate @args;
	$tr =~ s/[\r\n]/ /g;
	$witem->command ("/say $tr");
}

Irssi::command_bind ('translate', \&cmd_translate);
