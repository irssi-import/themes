# angelic4.4.1 2026-08-09
## changelog
* remove config
* remove asciiart
* remove startup
* remove scripts/autorun/
* remove scripts/HOSC/
* remove scripts/old
* remove scripts from other source

## scripts
### source 
* angelic
  + ban_affects.pl
  + chanshow.pl
  + translate.pl
  + whoami.pl
* https://github.com/joostvunderink/irssi-hosc/tree/master
* https://scripts.irssi.org/
* https://github.com/jamo/irssi-stuff/blob/778109aba5ca70626d5a4032e6eb77cd42788938/scripts/geoip2.pl
* https://github.com/oohlaf/dotfiles/blob/77ab1783b83f1dd7d9672aef28976df4ebad3d6d/irssi/.irssi/scripts/geoip.pl
* https://github.com/irssi/scripts.irssi.org/pull/4/changes/b7727d705d35f24d000abbb1996ea34e7018f332

### compare to current:
|filename                      | angelic                       | current                       |
|---                           | ---                           | ---                           |
|active_notify.pl              | 0.07                          | 0.07                          |
|anotherway.pl                 | 2003010201                    | 2003010201                    |
|ascii.pl                      | 1.6.3                         | 1.6.3                         |
|auto_whois.pl                 | 0.9                           | 0.9                           |
|autocycle.pl                  | 0.4                           | 0.4                           |
|awaylogcnt.pl                 | 0.2                           | 0.2                           |
|bitlbee_blist.pl              | 0.1                           | 0.5                           |
|bitlbee_tab_completion.pl     | 1.00                          | 1.3                           |
|bitlbee_typing_notice.pl      | 0.9                           | 1.7.3                         |
|chanact.pl                    | 0.5.14                        | 0.6.0                         |
|chansort.pl                   | 1.4                           | 1.5.1                         |
|clones.pl                     | 2.01                          | 2.01                          |
|country.pl                    | 1.0.1                         | 1.0.1                         |
|friends_shasta.pl             | 2.4.9                         | 2.4.9                         |
|geoip.pl                      | 0.0.3                         | 0.0.4-r1                      |
|hide.pl                       | 0.0.7                         | 0.0.7                         |
|hilightwin.pl                 | 0.02                          | 1.00                          |
|ho_easykline.pl               | 25/02/2003 19:29              | 2013-09-21 10:00:00+02        |
|ho_gline.pl                   | 6 August 2004 15:54:32        | 2013-09-21 10:00:00+02        |
|ho_hammer.pl                  | 19 January 2003 13:07:07      | 2013-09-21 10:00:00+02        |
|ho_killreconnect.pl           | 04 April 2004 12:34:38        | 2013-09-21 10:00:00+02        |
|ho_lusercount.pl              | 24 April 2004 22:24:08        | 2013-09-21 10:00:00+02        |
|ho_manage.pl                  | 19 October 2004 22:27:30      | 2013-09-21 10:00:00+02        |
|ho_mkick.pl                   | 25 May 2004 22:53:46          | 2013-09-21 10:00:00+02        |
|ho_mkill.pl                   | 12 January 2003 21:53:46      | 2013-09-21 10:00:00+02        |
|ho_netmon.pl                  | 07 August 2004 12:27:30       | 2013-09-21 10:00:00+02        |
|ho_operwall.pl                | 06/04/2004 08:15              | 2013-09-21 10:00:00+02        |
|ho_qoper.pl                   | 04 April 2004 12:34:38        | 2013-09-21 10:00:00+02        |
|ho_sping.pl                   | 07 August 2004 12:27:30       | 2013-09-21 10:00:00+02        |
|ho_stats_l.pl                 |                               | 2013-09-21 10:00:00+02        |
|ho_stats_p.pl                 | 2004/09/05 18:48:14           | 2013-09-21 10:00:00+02        |
|ho_stats_y.pl                 |                               | 2013-09-21 10:00:00+02        |
|ho_sversion.pl                | 07 August 2004 12:27:30       | 2013-09-21 10:00:00+02        |
|ho_tfind.pl                   | 04 April 2004 12:34:38        | 2013-09-21 10:00:00+02        |
|ho_tools.pl                   | 24 April 2004 22:48:36        | 2013-09-21 10:00:00+02        |
|ircops.pl                     | 0.1                           | 0.1                           |
|keepnick.pl                   | 1.17                          | 1.19.1                        |
|mailcount.pl                  | 1.4.5                         | 1.4.5                         |
|mkick.pl                      | 0.9                           | 0.9                           |
|modelist-r.pl                 | 0.8.0-rc4                     | 0.8.0-rc4                     |
|nicklist.pl                   | 0.4.6                         | 0.4.12                        |
|queryresume.pl                | 2003021201                    | 2003021201                    |
|rainbow.pl                    | 1.4                           | 1.6                           |
|relm.pl                       | 1.0                           | 1.1                           |
|rotator.pl                    | 0.2.1                         | 0.2.1                         |
|screen_away.pl                | 0.9.7.1                       | 0.9.8.2                       |
|scriptassist.pl               | 2003020803                    | 2023111700                    |
|sysinfo277-irssi.pl           | 2.77                          | 2.79                          |
|sysinfo_dg.pl                 | 1.2                           | 1.3                           |
|sysinfoplus.pl                | 2.20                          | 2.21                          |
|thistory.pl                   | 1.05                          | 1.05                          |
|tlock.pl                      | 1.1                           | 1.1                           |
|tracknick.pl                  | 0.01                          | 0.02                          |
|trigger.pl                    | 1.0                           | 1.3.1                         |
|trustweb.pl                   | 2003020801                    | 2003020801                    |
|uptime.pl                     | 1.6                           | 1.6.1                         |
|url_log.pl                    | 0.2                           | 0.3                           |
|usercount.pl                  | 1.16                          | 1.20                          |
|whois.pl                      | 1.0                           | 1.0                           |
|wlstat.pl                     | 0.5                           | see adv_windowlist            |
|wordcompletition.pl           | 0.1                           | 0.2                           |

### residual:
|filename                      | angelic                       |
|---                           | ---                           |
|ban_affects.pl                |                               |
|chanshow.pl                   | 1.00                          |
|translate.pl                  |                               |
|whoami.pl                     |                               |
